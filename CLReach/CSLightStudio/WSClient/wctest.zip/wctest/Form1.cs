﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace wctest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        WebSocket4Net.WebSocket socket;
        private void Form1_Load(object sender, EventArgs e)
        {
            socket = new WebSocket4Net.WebSocket("ws://localhost:808/",null,WebSocket4Net.WebSocketVersion.Rfc6455);
            socket.DataReceived += onRecv;
            socket.MessageReceived += onRecvM;
            socket.Opened += onOpen;
            socket.Open();

        }
        void onOpen(object sender, EventArgs e)
        {
            Safe_Log("onOpen");
            socket.Send("hello there");
            
        }
        void onRecv(object sender,WebSocket4Net.DataReceivedEventArgs args)
        {
            Safe_Log("RD:"+args.Data.ToString());
        }
        void onRecvM(object sender, WebSocket4Net.MessageReceivedEventArgs args)
        {
            Safe_Log("R:" + args.Message);
        }
        void Safe_Log(string str)
        {
            this.Invoke((Action<string>)_Log, new object[] { str });
        }
        void _Log(string str)
        {
            if (this.listBox1.Items.Count > 10)
            {
                this.listBox1.Items.RemoveAt(0);
            }
            this.listBox1.Items.Add(str);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            socket.Send("hello there");
        }
    }
}
