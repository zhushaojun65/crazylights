﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WebSocket4Net
{
    public enum WebSocketVersion
    {
        None = -1,
        DraftHybi00 = 0,
        DraftHybi10 = 8,
        Rfc6455 = 13,
    }
}
